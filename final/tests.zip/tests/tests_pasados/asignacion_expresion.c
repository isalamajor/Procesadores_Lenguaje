#include <stdio.h>

int b = 6, c = 3;
int a;

main() {
    a = (b + c);  
    printf("%d", a);
}

//@ (main)

#include <stdio.h>

int ind;
int n;

print_even() {
    ind = 0;
    n = 40;
    for (ind = 2; ind <= n; ind = ind + 2) {
        printf("%d\n", ind);
        puts("Impreso ");
    }
}

main() {
    print_even();
}

//@ (main)

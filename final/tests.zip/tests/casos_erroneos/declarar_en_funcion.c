#include <stdio.h>

int b = 6, c = 3;

main() {
    int a; 
    a = b + c;
    printf("%d", a);
}

//@ (main)

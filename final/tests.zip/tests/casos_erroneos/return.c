#include <stdio.h>

int a = 6;

main() {
    printf("%d", a);
    a = a + 10;
    return a;
    
}

//@ (main)

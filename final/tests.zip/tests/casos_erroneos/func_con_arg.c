#include <stdio.h>

int b = 6, c;

funcion1(int arg){
    printf("%d", arg + 6);
}

main() {
    printf("%d", a);
    a = a + 10;    
}

//@ (main)
